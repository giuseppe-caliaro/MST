%%%% -*- Mode: Prolog -*-
%% mst.pl
%%Caliaro Giuseppe 859295
%%Di Lorito Andrea 844517
%%Longo Mirco 838315
                                                                                
%% new_graph/1
:- dynamic graph/1.
new_graph(G) :- graph(G), ! .
new_graph(G) :- assert(graph(G)), ! .


%% delete_graph/1
delete_graph(G) :- retractall(vertex(G, _)),
		   retractall(arc(G, _, _, _)), retract(graph(G)), ! .


%% new_vertex/2
:- dynamic vertex/2.
new_vertex(G, V) :- vertex(G, V), ! .
new_vertex(G, V) :- graph(G), assert(vertex(G, V)), ! .


%% graph_vertices/2
graph_vertices(G, Vs) :- findall(V, vertex(G, V), Vs).


%% listvertex/1 
list_vertices(G) :- listing(vertex(G, _V)).


%% new_arc/4 
:- dynamic arc/4.
new_arc(G, U, V) :- new_arc(G, U, V, 1).
new_arc(G, U, V, Weight) :- arc(G, U, V, _), delete_arc(G, U, V, _),
			    new_arc(G, U, V, Weight).
new_arc(G, U, V, Weight) :- graph(G), U \= V ,vertex(G, U), vertex(G, V),
			    assert(arc(G, U, V, Weight)),
			    assert(arc(G, V, U, Weight)), ! .


%%delete_arc/4 
delete_arc(G, U, V, _) :- graph(G), vertex(G, U), vertex(G, V),
			  retract(arc(G, U, V, _)), retract(arc(G, V, U, _)),
			  ! .


%% graph_arcs/2 
:- dynamic arc/4.
graph_arcs(G, Es) :- findall(arc(U, V, Weight), arc(G, U, V, Weight), Es).


%% vertex_neighbors/3 
vertex_neighbors(G, V, Ns) :- findall(arc(G, V, W, Z), arc(G, V, W, Z), Ns).


%% adjs/3 
adjs(G, V, Vs) :- findall(W, arc(G, V, W, _Weight), Vs).


%%list_arcs/1 
list_arcs(G) :- listing(arc(G, _U, _V, _Weight)).


%%list_graph/1
list_graph(G) :- list_vertices(G), list_arcs(G).


%%read_graph/2
read_graph(G, Filename) :- new_graph(G),
			   csv_read_file(Filename, Rows,[functor(table),
			   arity(3), separator(0'\t)]), maplist(G, Rows).
maplist(_, []).
maplist(G, [H | T]) :- arg(1, H, X), arg(2, H, Y), arg(3, H, Z),
		       new_vertex(G, X), new_vertex(G, Y), new_arc(G, X, Y, Z),
		       maplist(G, T), ! .


%%write_graph/2 
write_graph(G, FileName) :- write_graph(G, FileName, graph).

write_graph(G, FileName, graph) :- graph_arcs(G, Es),
				   csv_write_file(FileName, Es,
				   [separator(0'\t)]).

write_graph(G, FileName, edges) :- csv_write_file(FileName, G,
				   [separator(0'\t)]).


:- dynamic vertex_key/3.
:- dynamic vertex_previous/3.


mst_prim(G, Source) :- retractall(vertex_key(_, _, _)),
		       retractall(vertex_previous(_, _, _)), vertex(G, Source),
		       arc(G, Source, _, _), new_heap(heap), lista_vertici(G, L),
		       inizializza(G, Source, L), set_adjs(G, Source, heap),
		       heap_entry(heap, 1, _, V),
		       estrai(heap, V, G), delete_heap(heap), ! .

lista_vertici(Grafo, Lista) :- findall(V, vertex(Grafo, V), Lista).

inizializza(Grafo, Source, []) :- retract(vertex_key(Grafo, Source, inf)) ,
				  assert(vertex_key(Grafo, Source, 0)),
				  assert(vertex_previous(Grafo, Source, nil)),
				  ! .
inizializza(Grafo, Source, [X | Xs]) :-  assert(vertex_key(Grafo, X, inf)),
					 inizializza(Grafo, Source, Xs).

set_adjs(Grafo, Source, Heap) :- adjs(Grafo, Source, Vs),
				 adiacenti(Heap, Vs, Source, Grafo), ! .
adiacenti(_Heap, [], _Source, _Grafo) :- ! .
adiacenti(Heap, [X | Xs], Source, Grafo) :- vertex_previous(Grafo, X, _),
					    adiacenti(Heap, Xs, Source, Grafo).
adiacenti(Heap, [X | Xs], Source, Grafo) :- arc(Grafo, Source, X, Weight),
					    arco(Source, X, Weight) =.. Node,
					    heap_insert(Heap, Weight, Node),
					    adiacenti(Heap, Xs, Source, Grafo).

estrai(Heap, V, Grafo) :- heap(Heap, S), S is 1, heap_entry(Heap, 1, K, V),
			  heap_extract(Heap, K, V),
			  nth1(2, V, Padre), nth1(3, V, Figlio),
			  nth1(4, V, Peso), new_vertex_key(Grafo, Figlio, Peso),
			  new_vertex_previous(Grafo, Figlio, Padre), ! .

estrai(Heap, V, Grafo) :- heap_entry(Heap, 1, K, V), heap_extract(Heap, K, V),
			  nth1(2, V, Padre), nth1(3, V, Figlio),
			  nth1(4, V, Peso), new_vertex_key(Grafo, Figlio, Peso),
			  new_vertex_previous(Grafo, Figlio, Padre),
			  set_adjs(Grafo, Figlio, Heap),
			  heap_entry(Heap, 1, _K1, V1), estrai(Heap, V1, Grafo).

new_vertex_key(Grafo, V, K) :- vertex_key(Grafo, V, K1),
			       new_vertex_key2(Grafo, V, K, K1).
new_vertex_key2(_Grafo, _V, K, Z) :- K >= Z, ! .
new_vertex_key2(Grafo, V, K, Z) :- retract(vertex_key(Grafo, V, Z)),
				   assert(vertex_key(Grafo, V, K)), ! .

new_vertex_previous(Grafo, Figlio, _Padre) :- vertex_previous(Grafo, Figlio, _),
					      ! .
new_vertex_previous(Grafo, Figlio, Padre) :-
  assert(vertex_previous(Grafo, Figlio, Padre)), ! .


mst_get(Grafo, Source, PreorderTree) :- new_graph(grafo_get),
  findall(Figlio, vertex_previous(Grafo, Figlio, Source), L), 
  figli_get(Grafo, L),
  findall(arc(Grafo, A, B, C), arc(grafo_get, A, B, C), PreorderTree),
  retractall(arc(grafo_get, _, _, _)), retract(graph(grafo_get)), ! .


figli_get(_Grafo, []) :- ! .
figli_get(Grafo, [X | Xs]) :- vertex_key(Grafo, X, Key),
  vertex_previous(Grafo, X, Padre),
  arc(Grafo, Padre, X, Key),
  assert(arc(grafo_get, Padre, X, Key)), 
  findall(Figlio, vertex_previous(Grafo, Figlio, X), L),
  figli_get(Grafo, L),
  figli_get(Grafo, Xs).


%% new_heap/2 
:- dynamic heap/2.
new_heap(H) :- heap(H, _S), ! , write('gia esistente').
new_heap(H) :- assert(heap(H, 0)), ! .

new_heap(H, _) :- heap(H, _), ! .
new_heap(H, S) :- assert(heap(H, S)), ! .


%%new_heap_entry/4.
:-dynamic heap_entry/4.
new_heap_entry(H, _, _, V) :- heap_entry(H, _, _, V), ! .
new_heap_entry(H, P, K, V) :- assert(heap_entry(H, P, K, V)), ! .


%%delete_heap/1
delete_heap(H) :- retractall(heap_entry(H, _, _, _)), retract(heap(H, _)).


%%heap_has_size/2
heap_has_size(H, S) :- heap(H, S).


%%heap_empty/1
heap_empty(H) :- heap(H, S), S == 0, ! .


%%heap_not_empty/1
heap_not_empty(H) :- heap(H, S), S \= 0, ! .


%%heap_head/3 
heap_head(H, K, V) :- heap_entry(H, 1, K, V).


%%list_heap/1
list_heap(H) :- listing(heap_entry(H, _, _, _)).


%%heap_insert/3
:-dynamic node/3.
heap_insert(H, _K, V) :- heap_entry(H, _, _, V), ! .
heap_insert(H, K, V) :- heap(H, S), retract(heap(H, _)), Size is S + 1,
			new_heap(H, Size), new_heap_entry(H, Size, K, V),
			heapify(H, Size).


%%heapify/2
heapify(_H, K) :- K = 1, ! .
heapify(H, K) :- heap_entry(H, K, K1, _V1), Dad is floor(K/2),
		 heap_entry(H, Dad, K2, _V2), K1 >= K2, ! .
heapify(H, K) :- heap_entry(H, K, K1, V1), Dad is floor(K / 2),
		 heap_entry(H, Dad, K2, V2), K1 < K2,
		 retract(heap_entry(H, K, K1, V1)),
		 retract(heap_entry(H, Dad, K2, V2)),
                 new_heap_entry(H, K, K2, V2), new_heap_entry(H, Dad, K1, V1),
		 heapify(H, Dad).


%%modify_key/4
modify_key(H, NewKey, OldKey, V) :- heap(H, A), heap_entry(H, P, OldKey, V),
				    A < (P * 2),
				    retract(heap_entry(H, P, OldKey, V)),
				    new_heap_entry(H, P, NewKey, V),
				    heapify(H, P), ! .

modify_key(H, NewKey, OldKey, V) :- heap(H, A), heap_entry(H, P, OldKey, V),
				    A is P * 2, Pos1 is P * 2,
				    heap_entry(H, Pos1, Key, Ver),
				    retract(heap_entry(H, P, OldKey, V)),
				    retract(heap_entry(H, Pos1, Key, Ver)),
				    new_heap_entry(H, Pos1, OldKey, V),
				    new_heap_entry(H, P, Key, Ver),
				    modify_key(H, NewKey, OldKey, V).

modify_key(H, NewKey, OldKey, V) :- heap(H, A), heap_entry(H, P, OldKey, V),
				    A > P * 2, Pos1 is P * 2,
				    Pos2 is (P * 2) + 1,
				    heap_entry(H, Pos1, Key, Ver),
				    heap_entry(H, Pos2, Key2, _Ver2),
				    Key =< Key2,
				    retract(heap_entry(H, P, OldKey, V)),
				    retract(heap_entry(H, Pos1, Key, Ver)),
				    new_heap_entry(H, Pos1, OldKey, V),
				    new_heap_entry(H, P, Key, Ver),
				    modify_key(H, NewKey, OldKey, V), ! .

modify_key(H, NewKey, OldKey, V) :- heap(H, A), heap_entry(H, P, OldKey, V),
				    A > P * 2, Pos1 is P * 2,
				    Pos2 is (P * 2) + 1,
				    heap_entry(H, Pos1, Key, _Ver),
				    heap_entry(H, Pos2, Key2, Ver2),
				    Key > Key2,
				    retract(heap_entry(H, P, OldKey, V)),
				    retract(heap_entry(H, Pos2, Key2, Ver2)),
				    new_heap_entry(H, Pos2, OldKey, V),
				    new_heap_entry(H, P, Key2, Ver2),
				    modify_key(H, NewKey, OldKey, V), ! .


%% heap_extract/3 
heap_extract(H, K, V) :- heap(H, S), retract(heap_entry(H, 1, K, V)),
			 sistema(H, S, 2, 0).

sistema(_H, S, B, _X) :- B > S, ! .
sistema(H, S, B, X) :- retract(heap(H, _)), new_heap(H, X),
		       retract(heap_entry(H, B, K, V)), heap_insert(H, K, V),
		       C is (B + 1), Y = (X + 1), sistema(H, S, C, Y).


%% end of file mst.pl