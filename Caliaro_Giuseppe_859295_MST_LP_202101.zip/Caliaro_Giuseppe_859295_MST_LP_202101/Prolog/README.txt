LP_E1P_2020/2021_MST: Minimum Spanning Trees

Componenti del gruppo: 
Caliaro Giuseppe 859295
Di Lorito Andrea 844517
Longo Mirco 838315

mst.pl obbiettivo: Calcolare il minimum spanning tree, di un determinato albero in input, connesso, non orientato, con distanze tra nodi non negative.  
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------

Spiegazione predicati implementati:


INTERFACCIA PROLOG PER LA MANIPOLAZIONE DEI GRAFI


new_graph(G): Questo predicato inserisce un nuovo grafo G nella basi-dati di prolog.


delete_graph(G): Rimuove tutto il grafo G (vertici ed archi inclusi) dalla base-dati prolog.


new_vertex(G, V): Aggiunge il vertice V nella base_dati prolog, controllando che esista il grafo G.


graph_vertices(G, Vs): Questo predicato è vero quando Vs è una lista contenente tutti i vertici di G. 


list_vertices(G): Questo predicato stampa alla console dell'interprete Prolog una lista dei vertici del grafo G, atraverso il predicato listing/1.


new_arc(G, U, V, Weight): Aggiunge l'arco arc(G, U, V, W) nella base_dati Prolog, dove G rappresenta il grafo di appartenenza, U il vertice di partenza dell'arco, V il vertice di arrivo dell'arco, Weight il peso dell'arco, se non viene specificato il peso dell'arco viene impostato ad 1 di default.
Se verifica che l'arco in input ha i vertici uguali ad uno già esistente, lo sostituisce con quello "nuovo".
Andiamo a creare anche l'arco inverso che andremo ad utilizzare per trovare gli adiacenti di un determinato vertice.


delete_arc(G, U, V, _): cancella l'arco in input dalla base_dati Prolog, attraverso il predicato retract.
 

graph_arcs(G, Es): Questo predicato è vero quando Es è una lista di tutti gl archi presenti in G, attraverso il predicato findall/3.


vertex_neighbors(G, V, Ns): Questo predicato è vero quando V è un vertice di G e Ns è una lista contenente gli archi, arc(G, U, V, Weight), che portano ai vertici immediatamente raggiungibili da V, attraverso il predicato findall/3.
 

adjs(G, V, Vs): Questo predicato è vero quando V è un vertice di G e Vs è una lista contenente i vertici immediatamente raggiungibili da V, attraverso il predicato findall/3.


list_arcs(G): Questo predicato stampa alla console dell'interprete Prolog una lista deigli arco del grafo G, atraverso il predicato listing/1.


list_graph(G): Questo predicato stampa alla console dell'inerprete una lista dei vertici e degli archi del grafo G richiamando list_vertices(G) e list_arcs(G).


read_graph(G, Filename): Questo predicato crea un nuovo grafo G (vertici ed archi inclusi), estraendo i dati da un file .csv, il file .csv è composto da 3 colonne ed
un numero indefinito di righe, ogni riga rappresenta un arco, la prima colonna rappresenta il vertice di partenza dell'arco, la seconda il vertice di arrivo,
mentre la terza il peso dell'arco tra i due vertici. 
Le colonne sono intervallate da un "tab", il predicato è vero se e solo se negli eventuali numeri decimali, la parte intera è separata da quella decimale da un punto.   


write_graph(G, FileName,  Type): il predicato è vero quando FileName è un file .csv che rispetta il formato descritto per read_graph/2, se Type corrisponde a graph andreamo ad utilizzare graph_arcs/2 per creare un lista degli archi (ed utilizzarla per creare il file), mentre se Type è edges G corrisponderà gia alla lista.



 
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------



MST IN PROLOG

vertex_key(G, V, K): Questo predicato, dichiarato dynamic, durante e dopo l'esecuzione del predicato mst_prim(G, Source) 
contiene il peso dell'arco minimo K che connette il vertice V all'albero minimo.
Questo predicato viene asserito nella base_dati Prolog attraverso new_vertex_key(Grafo, V, K) e new_vertex_key2(Grafo, V, K, Z).

new_vertex_key(Grafo, V, K): Questo predicato controlla nella base_dati Prolog l'esistenza di una vertex_key(G, V, K) 
per il vertice V e il grafo G passato in input dal predicato. Se esiste già una chiave associata al grafo G e
al vertice V allora passa i valori a new_vertex_key2(G, V, K, Z) 
dove Z è la chiave trovata nella base di dati e K è la chiave nuova che andiamo a controllare.

new_vertex_key2(Grafo, V, K, Z): Questo predicato esegue prima di tutto un controllo, se la chiave 
che vogliamo aggiungere è maggiore/uguale di quelle nella base_dati Prolog un cut blocca l'esecuzione.
Nel caso in cui la chiave fosse invece minore, esegue una retract della vertex_key(G, V, Z) precedente e 
una assert della vertex_key(G, V, K) con la chiave appena trovata. 

vertex_previous(G, V, U): Questo predicato, dichiarato dynamic, alla fine dell'esecuzione del predicato mst_prim(G, Source) 
conterrà nella base_dati Prolog il genitore (V) di ogni vertice (U) collegato nel grafo (G).
Questi predicati saranno asseriti durante l'esecuzione dell'algoritmo di Prim
mediante un predicato chiamato new_vertex_prevous(G, V, U).

new_vertex_previous(Grafo, Figlio, Padre): questo predicato prima di tutto controlla se esiste 
nella base_dati Prolog un vertice Padre qualsiasi per il vertice Figlio. 
Se questa condizione risulta verificata significa che il relativo vertice 
Figlio è già stato visitato quindi blocca l'esecuzione con un cut.
Nel caso in cui la condizione non fosse verificata il predicato esegue una assert nella base_dati Prolog 
creando così una nuova vertex_key.

mst_prim(G,Source): questo predicato è vero se nella base-dati Prolog sono contenute tutte le vertex_key(G, V, K)
e le vertex_previous(G, V, U) per ogni vertice V appartenente al Grafo G rispettando
le proprietà di un MST.
Il predicato è composto da due parti: una parte di inizializzazione e una parte ricorsiva.

Inizializzazione
La parte di inizializzazione esegue una retractall di tutte le vertex_key e vertex_prevoius create 
in una possibile esecuzione precedente dell'algoritmo di Prim effettuato sul grafo G.
Dopo aver eseguito la retractall unifica nella base-dati Prolog trovando il vertice Source 
con cui inizieremo l'algoritmo ed esegue un controllo sull'esistenza di almeno un arco che collega 
Source ad un qualsiasi altro vertice, così da assicurarsi che il vertice Source da cui partirà l'algoritmo non sia un nodo isolato. 
Dopo essersi assicurati l'esistenza del vertice Source e di un relativo arco che parte da Source il predicato creerà un nuovo heap. 
Ora il predicato costruirà una lista L contenente tutti i vertici di G con il predicato lista_vertici(G, L)
e passerà la lista al predicato inizializza(Grafo, Source, L).

inizializza(Grafo, Source, L): questo predicato svuota la lista L contenente tutti i vertici e pone per ogni vertice V 
vertex_key(Grafo, V, inf), dopo aver svuotato la lista imposterà la vertex_key e la
la vertex_previous della Source quindi esegue una retract
della vertex_key(Grafo, Source, inf) per eseguire una assert di vertex_key(Grafo, Source, 0)
e un assert della vertex_previous(Grafo, Source, nil).

Ora, con il predicato set_adjs, inseriamo nello heap appena creato gli archi che partono dalla 
sorgente e portano ad un vertice adiacente, questo predicato sarà utilizzato anche
per il passo ricorsivo.

set adjs(Grafo, Source, Heap): questo predicato è composto da 2 predicati, adjs(Grafo, Source, Vs) 
che pone nella lista Vs gli adiacenti di source, e il predicato adiacenti(Heap, L, Source, Grafo)
che ricorsivamente svuota la lista L contenente i vertici di Source inserendo nello heap l'arco che
da Source porta al vertice X adiacente, questo avviene se e solo se controllando la vertex_previous
del vertice X adiacente non esiste già un genitore, questo significa che il vertice X non è stato visitato.

Ora unificando con la heap_entry in prima posizione nello heap troveremo l'arco con peso minore che collega
il vertice Source ad un vertice adiacente, questa heap_entry è passata al predicato
estrai(Heap, V, Grafo) che eseguirà il passo ricorsivo. 


Ricorsiva

Il passo ricorsivo, che è il cuore del predicato mst_prim(G, Source), è composto dal predicato estrai(Heap, V, Grafo).
Questo predicato estrae ricorsivamente tutte le entries dello heap e termina quando lo heap sarà composto da una sola entry, 
che verrà estratta e terminerà la ricorsione.
 
estrai(Heap, V, Grafo): il predicato controlla con una heap_entry nella base-dati Prolog la entry che è in prima posizione nello heap.
L'entry in prima posizione contiene nel campo V una stringa del tipo: [arco, Source, X, Weight], 
che collega il vertice Source (padre) ad un altro vertice X (figlio) con il peso Weight minimo.
Una volta estratti i valori della lista attraverso il predicato nth1/3, il predicato creerà ,nel caso in cui il vertice X non sia già stato visitato, una nuova 
vertex_previous, e nel caso trovi un peso minore, una nuova vertex_key.
Ora il predicato eseguirà ricorsivamente un'altra estrai con il vertice X.


Finita la ricorsione lo heap verrà eliminato.



mst_get(G, Source, PreorderTree): il predicato mst_get deve essere eseguito dopo aver eseguito l'mst_prim. Alla fine dell'esecuzione PreorderTree 
dovrà contenere una lista di archi dell'MST ordinata secondo un attraversamento preorder fatto rispetto al peso dell'arco.
mst_get inizialmente creerà un nuovo grafo chiamato grafo_get che sarà utilizzato come grafo provvisorio. 
Ora una findall creerà una lista L con all'interno tutte i vertici che hanno come Padre il vertice Source nelle vertex_previous create
con l'esecuzione del predicato mst_prim, la lista L verrà passata al predicato figli_get(Grafo, L). 
Finita la ricorsione verranno eliminati tutti gli archi temporanei ed il grafo grafo_get.


figli_get(Grafo, [X | Xs]): questo predicato svuota la lista L ricorsivamente, si avvale quindi di un caso base che controllerà l'esistenza di almenno un elemento nella lista, il passo ricorsivo inizialmente crea un arco temporaneo unificando le informazioni ricavate da vertex_key e vertex_previous del vertice in testa alla lista.
Ora una findall creerà una lista L con all'interno tutte i vertici che hanno come Padre il vertice X in testa alla lista L.
Attravero una doppia ricorsione (nella prima viene passata L, mentre nella seconda Xs) visita l'MST in preorder.

  


-----------------------------------------------------------------------------------------------------------------------------------------------------------------------


MINHEAP IN PROLOG:


new_heap(H): Questo predicato inserisce un nuovo heap H con dimensione 0 nella base-dati Prolog se non esiste già uno heap con lo stesso nome, nel
caso in cui esistesse già uno heap con lo stesso nome non verrà creato e stamperà un messaggio di errore specifico.


new_heap(H, S): Questo predicato inserisce un nuovo heap H nella base-dati Prolog specificando la grandezza S dello heap in input.


delete_heap(H): Rimuove tutto lo heap H (incluse tutte le “entries”) dalla base-dati Prolog.


heap_has_size(H, S): Questo predicato è vero quanto S è la dimensione corrente dello heap.


heap_empty(H): Questo predicato è vero quando lo heap H non contiene elementi, quindi 
viene controllata la dimensione S che deve essere uguale a 0.


heap_not_empty(H): Questo predicato è vero quando lo heap H contiene almeno un elemento, quindi viene
controllata la dimensione S che deve essere diversa da 0.


heap_head(H, K, V): Il predicato heap_head è vero quando l’elemento dello heap H con chiave minima K è V, questa entry
corrisponde all'elemento in prima posizione dello heap.


heap_insert(H, K, V): Il predicato heap_insert è vero quando l’elemento V è inserito nello heap H con chiave K, nel primo caso base controlla che non esista una entry con lo stesso V già esistente, in caso contrario procederà all'inserimento nella prima posizione disponibile, l'incremento della grandezza dello heap ed alla ristrutturazione dello heap utilizzando heapify(H, K).


heapify(H, K): il predicato è vero quando lo heap H dopo aver rimosso o aggiunto una entry mantiene le proprietà di un minheap.
Il predicato ha tre casi base:
Il primo effettua un cut nel caso in cui la nuova entry sia in prima posizione. 
Secondo caso verifica che il figlio sia "più grande" del padre quindi termina l'esecuzione dato che la heap propiety è verificata.
Il terzo caso inizia controllando che il figlio sia "minore" del padre, verificato ciò si procede a scambiare i due nodi e ricorsivamente richiamerà heapify(H, Dad).


modify_key(H, NewKey, OldKey, V): Questo predicato continua a scambiare il nodo la cui chiave dovrà essere cambiata filgio minore, una volta arrivato a non avere più figli verrà scmbiata la chiave e chiamata una heapfy. Contiene 4 casi base, il primo controlla che il nodo non abbia figli e procede al cambio della chiave in input, il secondo controlla che esista solamente il figlio sinitro e procede con lo scambio tra i due, il terzo ed il quarto controllano che esista anche il figlio destro e trovano il minore dei due, successivamente scambiano il nodo selezionato con il figlio minore. 


heap_extract(H, K, V): Questo predicato elimina dalla base-dati Prolog l'entry in prima posizione nello heap, richiamando sistema(H, S, B, X) che si preoccuperà della ristrutturazione dello heap.


sistema(H, S, B, X): Il primo caso base serve per non superare la grandezza massima dello heap e termina la ricorsione del predicato. 
Il secondo caso ristruttura lo heap partendo dalla seconda posizione fino all'ultima, inserendo ogni entry in un nuovo heap di grandezza N-1.

