LP_E1P_2020/2021_MST: Minimum Spanning Trees

Componenti del gruppo: 
Caliaro Giuseppe 
Di Lorito Andrea
Longo Mirco 

mst.pl obbiettivo: Calcolare il minimum spanning tree, di un determinato albero in input, connesso, non orientato, con distanze tra nodi non negative.
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Spiegazione predicati implementati:


INTERFACCIA LISP PER LA MANIPOLAZIONE DEI GRAFI


Print-hash(hash-table): Data una determinata hash-table in input stampa a video la coppia chiave valore della hash table

New-graph(graph-id): Questa funzione crea un nuovo grafo

Is-graph(graph-id): Questa funzione ritorna l'ID del grafo oppure NIL

Delete-graph(graph-id): Questa funzione elimina tutti i contenuti delle hash table nel sistema riferite ad un determinato grafo. Per graphs elimina a livello locale, per le hash tables rimanenti chiama un'altra funzione (delete-val)

Delete-val(graph-id myhash): Questa funzione prende in input l'id di un grafo e una determinata hash table ed elimina tutti i contenuti relativi a quel grafo dalla hash table

New-vertex (graph-id vertex-id): Questa funzione crea un vertice vertex-id all'interno di un grafo graph-id, non controlla che il grafo sia esistente per decisione del programmatore,
altrimenti si rischierebbero errori con gli inserimenti automatici del professore

Graph-vertices (graph-id): Questa funzione ritorna la lista di vertici appartenenti al grafo graph-id

New-arc (graph-id vertex-id-1 vertex-id-2 &optional (weight 1): Questa funzione crea un arco tra il vertice 1 e il vertice 2 dati in input, qualora il peso non fosse inserito il programma lo setterebbe a 1 in automatico

Graph-arcs (graph-id): Questa funzione ritorna una lista degli archi di un determinato grafo

Graph-vertex-neighbors (graph-id vertex-id): Questa funzione ritorna una lista degli archi che portano o partono dal vertice vetrex-id

Graph-vertex-adjacent (graph-id vertex-id): Questa funzione ritorna una lista dei vertici collegati a vertex-id, per collegati si intende che esiste un cammino di lunghezza 1 che porta direttamente ad uno di questi

Graph-print(graph-id): Questa funzione stampa a video la lista di vertici e archi di un determinato grafo

-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

MINHEAP IN LISP:


New-heap(heap-id &optional (capacity 42)): Questa funzione crea uno heap di nome heap-id, qualora la grandezza dello heap non fosse inserita il programma la setterebbe automaticamente a 42

Delete-heap(heap-id): Questa funzione cancella lo heap dalla hash table *heaps*

Heap-empty(heap-id): Questa funzione ritorna t se lo heap è vuoto e nil se lo heap contiene almeno un elemento

Heap-not-empty (heap-id): Questa funzione richiama la heap-empty e ritorna t se lo heap contiene almeno un elemento e nil se lo heap è vuoto

Heap-id (value): Questa funzione dato in input lo heap-id di uno heap ritorna il suo id, torna utile per alleggerire il codice e renderlo più leggibile

Heap-size (value): Questa funzione ritorna la grandezza dello heap ovvero la quantità di elementi al suo interno diversi da nil

Heap-actual-heap (value): Questa funzione ritorna lo heap stesso dato un heap-id passato come value

Heap-head (heap-id): Questa funzione ritorna il primo elemento dello heap

Heap-insert (heap-id k v): La funzione heap-insert inserisce l'elemento v nel posto k di un determinato heap e poi chiama la heapify che controlla che vengano rispettate le caratteristiche del minheap

Heapify (myheap indice): Dato un determinato heap e un indice all'interno dello stesso questa funzione controlla che vengano rispettate le caratteristiche del minheap, qualora non lo fossero cambia la funzione scambia

Scambia (myarray heap-id indice valore): Questa funzione controlla che i due elementi presi in input rispettano i caratteri del minheap, se non li rispettano scambia gli elementi e chiama la heapfy in modo ricorsivo così da controllare
ogni possibile elemento figlio dello heap.

Heap-print (heap-id): Questa funzione stampa lo heap heap-id.

Print-arr (myarray indice): Questa funzione stampa gli elementi di un array fino a un dato indice, viene utilizzata nella heap-print per avere un codice più pulito. 

Heap-extract (heap-id): Questa funzione rimuove l'ultimo elemento dello heap e insieme alla copy-array crea un nuovo heap senza quell'elemento, il vecchio heap e i relativi dati vengono quindi eliminati e successivamente
sovrascritti dalla copy array (la copy-array si limita a sovrascrivere i dati, non ad eliminarli)

Copy-array (old-array ultimo-elemento heap-id): Questa funzione ricrea ricorsivamente l'array, quindi i valori dello heap e lavora insieme alla heap extract per creare un nuovo heap

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

MST IN LISP:

Mst-vertex-key (graph-id vertex-id):Questa funzione popola la tabella vertex-keys con il vertice successivo di vertex-id

Mst-vertex-previous (graph-id vertex-id): Questa funzione popola la tabella vertex-previous con il vertice precedente di vertex-id

Mst-prim (graph-id source): Questa funzione popola le hash-table vertex-keys e visited del valore source e degli altri valori presi dall'output di graph-vertices,
crea un nuovo heap e successivamente applica la funzione mst con input graph-id e source

Mst (graph-id source): Questa funzione controlla i vicini di souruce e li inserisce nello heap, poi chiama cammino-min

Cammino-min(graph-id): Questa funzione trova l'arco con peso minore che collega gli elementi dell'albero minimo con i restanti vertici dell'albero e in modo ricorsivo richiama l'mst sull'elemento successivo e ciclando in questo modo
controllerà tutti gli elementi dell'albero

Mst-get (graph-id source): Questa funzione ritorna la lista degli archi facenti parte dell'albero minimo

Create-figli (graph-id Source): Questa funzione dato un determinato grafo e un determinato vertice di partenza ritorna una lista degli archi collegati a source

Loop-childs(graph-id ord-childs): Questa è una funzione ricorsiva che richiama se stessa e la get sugli elementi restanti dell'albero non ancora analizzati.

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Abbiamo eseguito molte prove del progetto utilizzando la seguente base di dati:

(new-graph 'grafo)
(new-vertex 'grafo 'A)
(new-vertex 'grafo 'B)
(new-vertex 'grafo 'C)
(new-vertex 'grafo 'D)
(new-vertex 'grafo 'E)
(new-vertex 'grafo 'F)
(new-arc 'grafo 'A 'B '1)
(new-arc 'grafo 'A 'E '4)
(new-arc 'grafo 'A 'F '3)
(new-arc 'grafo 'B 'C '5)
(new-arc 'grafo 'C 'F '7)
(new-arc 'grafo 'C 'D '6)
(new-arc 'grafo 'D 'F '1)
(new-arc 'grafo 'D 'E '2)






